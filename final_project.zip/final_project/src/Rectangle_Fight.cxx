
#include "model.hxx"
#include "controller.hxx"

int
main()
{
    Model model;
    Controller controller(model);

    controller.run();
}